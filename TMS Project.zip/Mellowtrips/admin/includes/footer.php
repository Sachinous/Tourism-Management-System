<div class="copyrights">
	 <p>© 2021 Mellow Trips . All Rights Reserved </p>
</div>	
